This folder contains three .zip archives for InteractiveJPDwB. To use InteractiveJPDwB, simply unzip/unpack the appropriate archive for your operating system.

On LINUX:   application.linux64.zip

On MacOSX:  application.macosx.zip

On WINDOWS: application.windows64.zip

In the extracted folder, run the following executible: InteractiveJPDwB. 
